from flask import render_template, url_for, flash, redirect, request
from app import app, db, bcrypt
from models import User, Assessment, AssessmentResult
from flask_login import login_user, current_user, logout_user, login_required
from datetime import datetime

@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(name=name, email=email, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    assessments = Assessment.query.all()
    return render_template('dashboard.html', assessments=assessments)

@app.route('/create_assessment', methods=['GET', 'POST'])
@login_required
def create_assessment():
    if request.method == 'POST':
        name = request.form.get('name')
        total_marks = request.form.get('total_marks')
        passing_marks = request.form.get('passing_marks')
        date_scheduled = datetime.strptime(request.form.get('date_scheduled'), '%Y-%m-%d')
        duration = request.form.get('duration')
        assessment = Assessment(name=name, total_marks=total_marks, passing_marks=passing_marks,
                                date_scheduled=date_scheduled, duration=duration)
        db.session.add(assessment)
        db.session.commit()
        flash('Assessment created successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('create_assessment.html')

@app.route('/update_result', methods=['GET', 'POST'])
@login_required
def update_result():
    if request.method == 'POST':
        roll_number = request.form.get('roll_number')
        assessment_name = request.form.get('assessment_name')
        marks_secured = request.form.get('marks_secured')
        user = User.query.filter_by(id=roll_number).first()
        assessment = Assessment.query.filter_by(name=assessment_name).first()
        if user and assessment:
            grade = calculate_grade(marks_secured, assessment.total_marks)
            result = AssessmentResult(user_id=user.id, assessment_id=assessment.id, score=marks_secured,
                                      grade=grade, status='completed')
            db.session.add(result)
            db.session.commit()
            flash('Result updated successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid Roll Number or Assessment Name', 'danger')
    return render_template('update_result.html')

@app.route('/leaderboard')
@login_required
def leaderboard():
    results = AssessmentResult.query.order_by(AssessmentResult.score.desc()).all()
    leaderboard = []
    for result in results:
        user = User.query.get(result.user_id)
        assessment = Assessment.query.get(result.assessment_id)
        leaderboard.append({
            'rank': results.index(result) + 1,
            'student_name': user.name,
            'roll_number': user.id,
            'assessment_name': assessment.name,
            'score': result.score,
            'total_marks': assessment.total_marks,
            'percentage': (result.score / assessment.total_marks) * 100
        })
    return render_template('leaderboard.html', leaderboard=leaderboard)

def calculate_grade(score, total_marks):
    percentage = (score / total_marks) * 100
    if percentage >= 90:
        return 'A'
    elif percentage >= 80:
        return 'B'
    elif percentage >= 70:
        return 'C'
    elif percentage >= 60:
        return 'D'
    else:
        return 'F'
